module.exports = 
{
    "URI": "mongodb://127.0.0.1/book_store"
}