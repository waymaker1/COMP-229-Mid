let express = require('express');
let router = express.Router();

let indexController = require('../controllers/index');

console.log("Index Router ****");
/* GET home page. */
router.get('/', indexController.displayHomePage);

/* GET home page. */
router.get('/home', indexController.displayHomePage);

/* GET book page. */
router.get('/book', indexController.displayBookPage);

module.exports = router;